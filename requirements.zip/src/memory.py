from typing import List, Dict


class ConversationMemory:
    """
    Short-term conversation memory.

    Stores the conversation history so the assistant
    can remember previous turns during the current session.
    """

    def __init__(self):

        self.messages: List[Dict[str, str]] = []


    # ========================================================
    # Add Message
    # ========================================================

    def add_message(
        self,
        role: str,
        content: str,
    ):

        self.messages.append(
            {
                "role": role,
                "content": content,
            }
        )


    # ========================================================
    # Add User Message
    # ========================================================

    def add_user_message(self, content: str):

        self.add_message(
            role="user",
            content=content,
        )


    # ========================================================
    # Add Assistant Message
    # ========================================================

    def add_assistant_message(self, content: str):

        self.add_message(
            role="assistant",
            content=content,
        )


    # ========================================================
    # Get Conversation History
    # ========================================================

    def get_history(self) -> List[Dict[str, str]]:

        return self.messages


    # ========================================================
    # Clear Memory
    # ========================================================

    def clear(self):

        self.messages = []


    # ========================================================
    # Get Number of Messages
    # ========================================================

    def __len__(self):

        return len(self.messages)


# ============================================================
# Quick Test
# ============================================================

def main():

    memory = ConversationMemory()

    memory.add_user_message(
        "My name is Layla."
    )

    memory.add_assistant_message(
        "Nice to meet you, Layla!"
    )

    memory.add_user_message(
        "What are your payment methods?"
    )

    memory.add_assistant_message(
        "LumaCart accepts cash on delivery where available, "
        "cards, and digital payment options."
    )

    print("\nConversation History:\n")

    for message in memory.get_history():

        print(
            f"{message['role']}: "
            f"{message['content']}"
        )

    print(
        f"\nTotal messages: {len(memory)}"
    )


if __name__ == "__main__":
    main()